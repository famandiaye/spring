package com.example.CRUD.repository;

import com.example.CRUD.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<User, Long> {
  // Vous pouvez ajouter des méthodes personnalisées ici si nécessaire
  User findByUsername(String username);
}
