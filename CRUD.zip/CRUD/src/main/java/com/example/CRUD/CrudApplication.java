package com.example.CRUD;

import com.example.CRUD.model.User;
import com.example.CRUD.services.UserService;
import jakarta.validation.Validator;
import jakarta.validation.ConstraintViolation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Set;

@SpringBootApplication
public class CrudApplication implements CommandLineRunner {

	private static final Logger logger = LoggerFactory.getLogger(CrudApplication.class);

	@Autowired
	private UserService userService;

	@Autowired
	private Validator validator;

	public static void main(String[] args) {
		SpringApplication.run(CrudApplication.class, args);
	}

	@Override
	public void run(String... args) {
		createUser();
	}

	private void createUser() {
		User user = new User();
		user.setUsername("fama");
		user.setPassword("123455");

		try {
			validateUser(user);
			userService.createUser(user);
			logger.info("Utilisateur créé : {}", user.getUsername());
		} catch (Exception e) {
			logger.error("Erreur lors de la création de l'utilisateur : {}", e.getMessage());
		}
	}

	private void validateUser(User user) {
		Set<ConstraintViolation<User>> violations = validator.validate(user);

		if (!violations.isEmpty()) {
			StringBuilder sb = new StringBuilder("Erreurs de validation : ");
			violations.forEach(violation -> sb.append(violation.getMessage()).append(", "));
			throw new IllegalArgumentException(sb.toString());
		}
	}
}
